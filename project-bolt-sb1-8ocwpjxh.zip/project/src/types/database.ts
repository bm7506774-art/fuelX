export interface Patient {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  age: number | null;
  gender: 'male' | 'female' | null;
  weight: number | null;
  height: number | null;
  health_conditions: string[];
  allergies: string[];
  created_at: string;
  updated_at: string;
}

export interface DietPlan {
  id: string;
  patient_id: string;
  name: string;
  description: string | null;
  start_date: string | null;
  end_date: string | null;
  daily_calories: number | null;
  protein_grams: number | null;
  carbs_grams: number | null;
  fats_grams: number | null;
  status: 'active' | 'paused' | 'completed';
  created_at: string;
  updated_at: string;
  patient?: Patient;
}

export interface Meal {
  id: string;
  diet_plan_id: string;
  day_of_week: number;
  meal_type: 'breakfast' | 'snack_morning' | 'lunch' | 'snack_afternoon' | 'dinner' | 'snack_evening';
  name: string;
  description: string | null;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  created_at: string;
}

export interface FoodItem {
  id: string;
  meal_id: string;
  name: string;
  quantity: number;
  unit: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  created_at: string;
}

export type PatientInsert = Omit<Patient, 'id' | 'created_at' | 'updated_at'>;
export type DietPlanInsert = Omit<DietPlan, 'id' | 'created_at' | 'updated_at' | 'patient'>;
export type MealInsert = Omit<Meal, 'id' | 'created_at'>;
export type FoodItemInsert = Omit<FoodItem, 'id' | 'created_at'>;
