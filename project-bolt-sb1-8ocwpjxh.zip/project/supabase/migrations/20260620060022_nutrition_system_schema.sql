-- Patients table
CREATE TABLE patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  age INTEGER,
  gender TEXT CHECK (gender IN ('male', 'female')),
  weight DECIMAL(5,2),
  height DECIMAL(5,2),
  health_conditions TEXT[],
  allergies TEXT[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Diet plans table
CREATE TABLE diet_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  start_date DATE,
  end_date DATE,
  daily_calories INTEGER,
  protein_grams INTEGER,
  carbs_grams INTEGER,
  fats_grams INTEGER,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'paused', 'completed')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Meals table
CREATE TABLE meals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  diet_plan_id UUID REFERENCES diet_plans(id) ON DELETE CASCADE,
  day_of_week INTEGER CHECK (day_of_week BETWEEN 0 AND 6),
  meal_type TEXT NOT NULL CHECK (meal_type IN ('breakfast', 'snack_morning', 'lunch', 'snack_afternoon', 'dinner', 'snack_evening')),
  name TEXT NOT NULL,
  description TEXT,
  calories INTEGER DEFAULT 0,
  protein INTEGER DEFAULT 0,
  carbs INTEGER DEFAULT 0,
  fats INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Food items table
CREATE TABLE food_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meal_id UUID REFERENCES meals(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  quantity DECIMAL(6,2),
  unit TEXT,
  calories DECIMAL(6,2) DEFAULT 0,
  protein DECIMAL(6,2) DEFAULT 0,
  carbs DECIMAL(6,2) DEFAULT 0,
  fats DECIMAL(6,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE diet_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE meals ENABLE ROW LEVEL SECURITY;
ALTER TABLE food_items ENABLE ROW LEVEL SECURITY;

-- RLS Policies for patients
CREATE POLICY "select_patients" ON patients FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_patients" ON patients FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_patients" ON patients FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_patients" ON patients FOR DELETE TO authenticated USING (true);

-- RLS Policies for diet_plans
CREATE POLICY "select_diet_plans" ON diet_plans FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_diet_plans" ON diet_plans FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_diet_plans" ON diet_plans FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_diet_plans" ON diet_plans FOR DELETE TO authenticated USING (true);

-- RLS Policies for meals
CREATE POLICY "select_meals" ON meals FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_meals" ON meals FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_meals" ON meals FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_meals" ON meals FOR DELETE TO authenticated USING (true);

-- RLS Policies for food_items
CREATE POLICY "select_food_items" ON food_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_food_items" ON food_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_food_items" ON food_items FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_food_items" ON food_items FOR DELETE TO authenticated USING (true);